# OCENCH

OCENCH: A One-Class Classification method based on Expanded Non-Convex Hulls

## Pip Installation
Pypi url: https://test.pypi.org/project/OCENCH/. To install, run the command

    pip install -i https://test.pypi.org/simple/ OCENCH